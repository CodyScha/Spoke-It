package com.example.filesystem_picker_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
